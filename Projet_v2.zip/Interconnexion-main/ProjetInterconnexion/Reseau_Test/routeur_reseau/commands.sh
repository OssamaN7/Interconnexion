#!/bin/bash
ip route add 120.0.160.0/21 via 120.0.176.13
echo "1" > /proc/sys/net/ipv4/ip_forward
ip route add 120.0.160.0/21 via 120.0.176.13
mkdir ossama
tail -f /dev/null