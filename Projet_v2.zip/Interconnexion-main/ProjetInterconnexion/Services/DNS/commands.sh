#!/bin/bash
 
ip route add 120.0.168.0/21 via 120.0.160.40 
ip route add 120.0.176.0/21 via 120.0.160.40 

echo -e "\033[0;31mBonjour je suis le serveur DNS\033[0m"

tail -f /dev/null