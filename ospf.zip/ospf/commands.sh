#!/bin/bash
set -e

#start ospfd et quagga

systemctl enable zebra
systemctl start zebra
sleep 5

systemctl enable frr
systemctl start frr
sleep 2

systemctl enable quagga
systemctl start quagga
systemctl enable ospfd
systemctl start ospfd
sleep 2
systemctl restart quagga

#Vérifier que les services sont lançés
systemctl status ospfd
systemctl status zebra

# Fonction pour ajouter une route avec des tentatives répétées
#add_route() {
 # local route="$1"
  #local gateway="$2"

  #until ip route add "$route" via "$gateway"; do
   # echo "Tentative d'ajout de la route $route via $gateway..."
    #sleep 1
  #done

  #echo "Route $route via $gateway ajoutée avec succès."
#}

# Active le forwarding IP
#echo "1" > /proc/sys/net/ipv4/ip_forward

# Configure the DHCP server
# Start le service DHCP
service isc-dhcp-server start
# Set up NAT by adding rule to iptables
iptables -t nat -A POSTROUTING -o eth1 -j MASQUERADE
# Configure default route to allow to client to communicate with WAN
ip route add default via 120.0.176.40

# Ajoute les routes avec vérification

#add_route "120.0.160.0/21" "120.0.176.13"

# Garder le conteneur actif
tail -f /dev/null
