#!/bin/bash

# Configurer l'interface WireGuard
echo "Configuration de l'interface WireGuard..."
ip link add wg0 type wireguard
ip addr add 10.0.0.2/24 dev wg0
wg setconf wg0 /etc/wireguard/wg0.conf
ip link set wg0 up

echo "Configuration terminée. Vous pouvez maintenant démarrer le VPN manuellement avec :"
echo "wg-quick up wg0"
