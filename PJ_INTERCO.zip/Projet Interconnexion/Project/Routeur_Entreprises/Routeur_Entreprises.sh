#ip route add 120.0.54.0/23 via 120.0.50.4
#ip route add 120.0.52.0/23 via 120.0.50.3

#ip route add 120.0.56.0/23 via 120.0.48.3
#ip route add 192.168.1.0/24 via 120.0.48.3