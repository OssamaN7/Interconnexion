#!/bin/bash
touch /var/lib/dhcp/dhcpd.leases
dhcpd